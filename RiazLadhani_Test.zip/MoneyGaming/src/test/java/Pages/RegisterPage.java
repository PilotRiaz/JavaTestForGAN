package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import junit.framework.Assert;

public class RegisterPage {
	
	private WebDriver driver;	
	
	private By TitleField = By.id("title");
	private By FirstNameField = By.id("forename");
	private By SurnameField = By.cssSelector("input[name='map(lastName)']");
	private By TermsCheckbox = By.id("termsCheckbox");
	private By JoinNowButton = By.id("form");	
	private By TermsCheckboxValidationLabel = By.xpath("//input[@name='map(terms)']//following-sibling::label");
	
	public RegisterPage(WebDriver Driver)
	{
		driver = Driver;
	}	
		
	public void SelectTitle(String Title)
	{
		Select TitleDropDown = new Select(driver.findElement(TitleField));
	    TitleDropDown.selectByValue(Title);		
	}
	
	public void EnterFirstName(String FName) 
	{
		driver.findElement(FirstNameField).sendKeys(FName);
	}
	
	public void EnterLastName(String SName) 
	{
		driver.findElement(SurnameField).sendKeys(SName);
	}
	
	public void ClickTermsAndConditions()
	{
		driver.findElement(TermsCheckbox).click();
	}
	
	public void ClickJoinNowButton()
	{
		driver.findElement(JoinNowButton).click();
	}
	
	public void VerifyTermsValidationMessageIsDisplayed(String Message)
	{
		String TermsCheckboxValidationText = driver.findElement(TermsCheckboxValidationLabel).getText();
		System.out.println("TermsCheckboxValidationText ****" + TermsCheckboxValidationText);
		Assert.assertTrue("This field is required", TermsCheckboxValidationText.contains(Message));
		
	}
}
