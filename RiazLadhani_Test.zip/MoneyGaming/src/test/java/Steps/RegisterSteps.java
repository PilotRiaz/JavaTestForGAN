package Steps;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import junit.framework.Assert;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import Pages.HomePage;
import Pages.RegisterPage;

import org.openqa.selenium.*;

public class RegisterSteps {

	WebDriver driver = null;
	HomePage Home_Page;
	RegisterPage Register_Page;
	
	@Given("I navigate to (.*)")
	public void i_navigate_to_httpsmoneygaming_qa_gameaccount_com() {
	    String projectPath = System.getProperty("user.dir");
		System.setProperty("webdriver.chrome.driver", projectPath + "/src/test/resources/drivers/chromedriver.exe");
	    driver = new ChromeDriver();
	    driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	    driver.manage().timeouts().pageLoadTimeout(30,TimeUnit.SECONDS);
	    driver.manage().window().maximize();
	    driver.navigate().to("https://moneygaming.qa.gameaccount.com");	    
	}

	@When("I click Join Now")
	public void i_click_join_now() {
	    Home_Page = new HomePage(driver);
		Home_Page.ClickJoinNowLink();
		//Register_Page = new RegisterPage(driver);
	    //Register_Page.ClickJoinNowLink();
		
		//driver.findElement(By.cssSelector("div[class='login_links'] [class='newUser green']")).click();
	}

	@And("^I enter a (.*) and (.*) and (.*)$")
	public void i_enter_a_mr_and_john_and_wayne(String Title, String FName, String SName) {
		Register_Page = new RegisterPage(driver);
		Register_Page.SelectTitle(Title);
		Register_Page.EnterFirstName(FName);
		Register_Page.EnterLastName(SName);
				
		//Select TitleDropDown = new Select(driver.findElement(By.id("title")));
	    //TitleDropDown.selectByValue(Title);
		//
		//driver.findElement(By.id("forename")).sendKeys(FName);
		//driver.findElement(By.cssSelector("input[name='map(lastName)']")).sendKeys(SName);		
	}

	@And("I accept the terms and conditions")
	public void i_accept_the_terms_and_conditions() {		
		
		Register_Page.ClickTermsAndConditions();
		//driver.findElement(By.id("termsCheckbox")).click();
	}

	@And("I click JoinNowButton")
	public void i_click_JoinNowButton() {
	    Register_Page.ClickJoinNowButton();
		//driver.findElement(By.id("form")).click();
	}

	@Then("^I can see the (.*)$")
	public void i_can_see_the_validationmessage(String Message) {		
		Register_Page.VerifyTermsValidationMessageIsDisplayed(Message);
		
		//String TermsCheckboxValidationText = driver.findElement(By.cssSelector("label[for='map(terms)']")).getText();
		
		//Assert.assertTrue("This field is required", TermsCheckboxValidationText.contains(Message));
		
		
		driver.close();
	    driver.quit();
	}
	
}
